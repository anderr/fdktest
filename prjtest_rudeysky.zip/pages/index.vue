<template>
  <div class="page">
    Добро пожаловать в тестовый ЛК
  </div>
</template>

<script>
  export default {
    name: 'home-page',
  }
</script>
