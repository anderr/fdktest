export default {
  name: state => state.name,
  surname: state => state.surname,
}
