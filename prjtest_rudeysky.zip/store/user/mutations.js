export default {
  setUserInfo: (state, val) => {
    state.name = val.name
    state.surname = val.surname
  }
};
