export default {
  setProfile: (state, val) =>{
    state.profile = val
  },
};
